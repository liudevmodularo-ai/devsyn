# DevSyn - Plataforma Autônoma de Desenvolvimento 🚀

## 🏗️ Arquitetura
- **Orquestrador**: Flask + Agentes Autônomos
- **APIs**: OpenAI/Gemini + Playwright fallback
- **Armazenamento**: ChromaDB vetorial + SQLite
- **Deploy**: VPS Linux (script automático)

## 🚀 Deploy VPS (Ubuntu 22.04)

```bash
# 1. No VPS:
apt update && apt install git -y
git clone https://github.com/SEU_USERNAME/devsyn.git /tmp/devsyn
cd /tmp/devsyn

# 2. Edite DOMAIN no install.sh
nano install.sh  # mude DOMAIN=seu.dominio.com

# 3. Execute (10min):
chmod +x install.sh
sudo ./install.sh
```

## 🛠️ Desenvolvimento Local
```bash
pip install -r requirements.txt
cp .env.example .env  # Configure API keys
python run.py
```
**Acesse:** http://localhost:5000

## 🔧 Configuração (.env)
```
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=...
MAX_AGENTS=10
```

## 📚 Documentação
- [ARQUITETURA.md](ARQUITETURA.md)
- [ESTADO_ATUAL.md](ESTADO_ATUAL.md)

[![Deploy](https://img.shields.io/badge/Deploy-VPS-green)](install.sh)
